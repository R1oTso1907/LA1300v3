﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lernatelier_einführungsProjekt
{
    
        class NumberGuessingGame

        {
            private Random zufall = new Random();
            private int geheimzahl;
            private int versuche = 0;
            private bool geraten = false;

            public void Start()
            {
                Console.WriteLine("Willkommen zum Number Guessing Spiel!");
                Console.WriteLine("Raten Sie bitte. Geben sie eine Zahl zwischen 1 und 100 ein.");
                geheimzahl = zufall.Next(1, 101);

                while (!geraten)
                {
                    Console.Write("Was vermutest du? ");
                    if (int.TryParse(Console.ReadLine(), out int vermutung))
                    {
                        versuche++;

                        if (vermutung < geheimzahl)
                        {
                            Console.WriteLine("Die geratene Zahl ist niedriger als die Geheimzahl.");
                        }
                        else if (vermutung > geheimzahl)
                        {
                            Console.WriteLine("Die geratene Zahl ist größer als die Geheimzahl.");
                        }
                        else
                        {
                            Console.WriteLine($"Herzlichen Glückwunsch! Du hast die Geheimzahl {geheimzahl} erraten.");
                            Console.WriteLine($"Du hast {versuche} Versuche gebraucht.");
                            geraten = true;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Ungültige Eingabe. Bitte gib eine ganze Zahl zwischen 1 und 100 ein.");
                    }
                }

                Console.WriteLine("Das Spiel ist beendet. Drücke eine beliebige Taste, um zu beenden.");
                Console.ReadKey();
            }
        }
    }

