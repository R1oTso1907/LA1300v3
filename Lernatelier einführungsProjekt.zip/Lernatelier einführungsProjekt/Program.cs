﻿namespace Lernatelier_einführungsProjekt
{
    

    class Program
    {
        static void Main()
        {
            NumberGuessingGame spiel = new NumberGuessingGame();
            spiel.Start();
        }

    }
}